//
//  Proj_SwitchApp.swift
//  Proj Switch
//
//  Created by Mac on 2021/4/25.
//

import SwiftUI

@main
struct Proj_SwitchApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
